# Recap of Assignment 3

Create a new program that forms teams of 5-6 people and assigns each team to a project.

The input to the program is a spreadsheet of preferences submitted by the people.
 * Each person gives their preferences for subteam members.  (A subteam may have size 1.)
 * Each person also gives 5 preferences for their project.

The member and project preferences must be consistent across all the members of a subteam.

The input spreadsheet is in file `cse403-preferences.csv`.  It has the following structure:
 * netID (a unique identifier) in column D.
 * project preferences in columns E-AY, with the project name in the column header and a value that is blank or is the person's preference ranking of that project.
 * subteam members in columns AZ-BE.

The output is a list of teams.  Each team contains 5-6 people and an assigned project.
A team consists of one or more subteams.

Subteams are not split up:  each person is in the same team as all of their preferred subteam members.

A team is assigned a project that is one of the 5 preferences for each of its members.

When a subteam has size 5 or 6, assign it to a team that is working on its most preferred project.

Given the above constraints, assign each team to the most preferred possible project.  More specicially, form teams so as to satisfy as many members' project preference as possible.
Ideally, every person would be in a team working on that person's most preferred project.
It is undesirable for anyone to be assigned to their #4 or #5 preferred project.

Submit a a4.zip that contains a folder a4/, under a4, you should have all your source code and a run.sh shell script.


You should write a `run.sh` under a4/ also such that it can 1. install necessary libs and 2. generate the output and save it to `out.csv`.

Your `out.csv` should have the following schema (team_proj_name, all_team_members), where first element is a string and second is a list of strings
For example, a row would look like:

('CookiesShallNotPass', '[m1, m2, m3, m4, m5, m6]')

This means that a group containing '[m1, m2, m3, m4, m5, m6]' is assigned the project 'CookiesShallNotPass'. 

(NOTE: this is in tuple format for demonstration purpose, please follow CSV format when running your code.)

(NOTE: please try to use pandas dataframe to parse your out.csv to smoke-test it works.)

### Linux or macOS (bash/zsh)

You should be able to run the following cmd.
Your `run.sh` should generate an `out.csv` and save it at your `/workspace/out.csv`.
Try the following command and see if you can access the `out.csv` after run.

```bash
docker run --rm -it -v "$(pwd)":/workspace -w /workspace ubuntu bash -lc "\
export DEBIAN_FRONTEND=noninteractive && \
apt-get update && apt-get install -y unzip python3 && \
unzip -o a4.zip && \
cd a4 && \
chmod +x run.sh && \
./run.sh my_input.csv /workspace/out.csv"
```

### Windows (PowerShell)

```powershell
docker run --rm -it -v "${PWD}:/workspace" -w /workspace ubuntu bash -lc "\
export DEBIAN_FRONTEND=noninteractive && \
apt-get update && apt-get install -y unzip python3 && \
unzip -o a4.zip && \
cd a4 && \
chmod +x run.sh && \
./run.sh my_input.csv /workspace/out.csv"
```

The resulting `out.csv` will be written next to `a4.zip` on the host machine for `my_input.csv` file inside your dir.

# Your task for Assignment 4

For Assignment 4, your task is to build on top of A3 by developing a set of test cases to evaluate your program, and revising your A3 implementation if necessary based on the results of testing.

I suggest that you carefully understand both the test cases and the project requirements to derive the expected outputs. You may use an LLM for assistance, but please make sure you fully understand your own code.

We will evaluate your refined code (from A3, and potentially revised in A4) using our private test suite. However, we promise that we will not include any test case that is impossible to solve under the given constraints. In other words, each test case in our private test suite will have a correct solution.

We noticed that all of you used Python for A3, so we will assume the same for A4. If not, please reach out.

After decompression, your code repository should look like the following:

a4/
  ├── your_code.py
  ├── ... ... ...
  ├── out.csv // from A3 original test case
  ├── Makefile // we provide makefile for compressing your code
  ├── successes.py
  ├── failures.py
  ├── run.sh // from A3 to run the algo, but now be ready to accept any input csv file (i.e., we will run commands such as  `./run.sh a.csv out.csv`), and it will generate a `out.csv` under the same dir as `a4.zip`
  ├── run_my_test.sh // from A4 to run your own test-suite
  ├── my_tests_describe.txt // verbal description of your test-case, what's your expected output, does your code generate the expected output
  └── my_tests.py // your test-suite in A4


Try NOT TO include any other large file or dir in your zip such as .git, venv.
If you run `make compress` you should see a compressed `a4.zip` in your parent dir for your code, please check if it contains correct content before submissions