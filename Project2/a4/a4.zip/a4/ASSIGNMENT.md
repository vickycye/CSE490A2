## How to navigate files

---- a4/planning/
Used for personal documentation, you can ignore this.

---- a4/run_tests.py
Has all the curated test cases for each possible problem and runs them. 

---- a4/team_assignment.py
This is the iterated and improved version from Assignment 3. 

---- a4/testing/TEST_CASES.md
Documentation regarding each test case's analysis and findings. 

---- a4/testing/test_data
Used for storing the .csv files for testing

---- a4/testing/test_results
Used for storing outputs from test .csv files to identify any inaccuracies in original code. 
