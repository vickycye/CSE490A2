import spacy

class RelationshipExtractor:
    def __init__(self):
        self.nlp = spacy.load("en_core_web_sm")
    
    def extract_relationships(self, text, entities):
        """
        Extract relationships between entities using dependency parsing.
        Returns a list of (subject, predicate, object) triplets.
        """
        doc = self.nlp(text)
        relationships = []
        
        # Create a mapping from token indices to entity text
        # Map raw entity text to cleaned unique entity text
        entity_text_map = {e['text']: e['text'] for e in entities.get('unique_entities', [])}
        
        # Also create reverse mapping for partial matches
        unique_entity_texts = [e['text'] for e in entities.get('unique_entities', [])]
        
        token_to_entity = {}
        for ent in doc.ents:
            # Find the best matching unique entity
            matched_entity = self._match_to_unique_entity(ent.text, unique_entity_texts)
            for token in ent:
                token_to_entity[token.i] = matched_entity if matched_entity else ent.text
        
        # Create a simple coreference map: pronouns -> most recent person entity
        coref_map = self._build_coref_map(doc, unique_entity_texts)
        
        # Look for verbs and auxiliaries that might indicate relationships
        for token in doc:
            if token.pos_ in ["VERB", "AUX"]:
                subject_entity = None
                predicate = token.lemma_
                
                # Find subject (check direct children first)
                for child in token.children:
                    if child.dep_ in ["nsubj", "nsubjpass"]:
                        subject_entity = self._get_entity_for_token(child, token_to_entity, coref_map)
                        break
                
                # If no subject found, check if this verb is part of a conjunction
                # and borrow the subject from the conjoined verb
                if not subject_entity:
                    subject_entity = self._find_shared_subject(token, token_to_entity, coref_map)
                
                # Skip if no subject found
                if not subject_entity:
                    continue
                
                # Find all objects through different dependency paths
                # This allows finding multiple relationships for the same verb/subject
                for child in token.children:
                    object_entity = None
                    current_predicate = predicate
                    
                    if child.dep_ == "prep":
                        # Look for pobj under the preposition
                        for prep_child in child.children:
                            if prep_child.dep_ == "pobj":
                                object_entity = self._get_entity_for_token(prep_child, token_to_entity, coref_map)
                                if object_entity:
                                    # Include preposition in predicate
                                    current_predicate = f"{token.lemma_} {child.text}"
                                    relationships.append({
                                        'subject': subject_entity,
                                        'predicate': current_predicate,
                                        'object': object_entity
                                    })
                    elif child.dep_ in ["dobj", "attr"]:
                        object_entity = self._get_entity_for_token(child, token_to_entity, coref_map)
                        if object_entity:
                            relationships.append({
                                'subject': subject_entity,
                                'predicate': current_predicate,
                                'object': object_entity
                            })
                        else:
                            # For "is/be" type verbs, also capture non-entity attributes
                            # like nationalities (Russian), occupations (scientist), etc.
                            if child.dep_ == "attr" and predicate in ["be", "am", "is", "are", "was", "were", "become"]:
                                attr_text = self._get_attribute_text(child)
                                if attr_text:
                                    relationships.append({
                                        'subject': subject_entity,
                                        'predicate': current_predicate,
                                        'object': attr_text
                                    })
                        
                        # Also check for entities in nested structures (e.g., "has a friend named Chat")
                        # Look for entities in the subtree of the direct object
                        for descendant in child.subtree:
                            if descendant.i != child.i:  # Don't check the same token
                                nested_entity = self._get_entity_for_token(descendant, token_to_entity, coref_map)
                                if nested_entity and nested_entity != object_entity:
                                    # Found an entity nested in the object phrase
                                    relationships.append({
                                        'subject': subject_entity,
                                        'predicate': current_predicate,
                                        'object': nested_entity
                                    })
        
        return relationships
    
    def _match_to_unique_entity(self, entity_text, unique_entity_texts):
        """
        Match a raw entity text to the best unique entity.
        Handles cases where "Stengel" should map to "Casey Stengel".
        """
        # Clean the entity text first
        import re
        entity_text_clean = re.sub(r'(\w+)"(\s+\w+)', r'\1 \2', entity_text)
        entity_text_clean = re.sub(r'^"(\w+)', r'\1', entity_text_clean)
        entity_text_clean = ' '.join(entity_text_clean.split())
        
        # Exact match
        if entity_text_clean in unique_entity_texts:
            return entity_text_clean
        
        # Find if this entity is a substring of any unique entity
        entity_lower = entity_text_clean.lower()
        for unique_entity in unique_entity_texts:
            unique_lower = unique_entity.lower()
            
            # Check if one contains the other
            if entity_lower in unique_lower or unique_lower in entity_lower:
                # Return the longer one
                return unique_entity if len(unique_entity) >= len(entity_text_clean) else entity_text_clean
            
            # Check if they share a last name (for person names)
            entity_parts = entity_text_clean.split()
            unique_parts = unique_entity.split()
            
            if len(entity_parts) > 0 and len(unique_parts) > 0:
                if entity_parts[-1].lower() == unique_parts[-1].lower():
                    # Prefer the longer name
                    return unique_entity if len(unique_parts) >= len(entity_parts) else entity_text_clean
        
        return entity_text_clean
    
    def _get_attribute_text(self, token):
        """
        Extract meaningful text from an attribute token (for non-entity attributes).
        Captures things like nationalities, occupations, etc.
        """
        # If it's a single adjective or noun, just return it capitalized
        if token.pos_ in ["ADJ", "NOUN", "PROPN"]:
            # Get the full noun phrase if it exists
            text_parts = [token.text]
            
            # Include any compound modifiers or adjectives
            for child in token.children:
                if child.dep_ in ["amod", "compound", "det"]:
                    text_parts.insert(0, child.text)
            
            result = " ".join(text_parts)
            # Capitalize for consistency (Russian, Scientist, etc.)
            return result.capitalize() if result else None
        
        return None
    
    def _find_shared_subject(self, verb_token, token_to_entity, coref_map):
        """
        Find a subject shared through conjunction.
        When verbs are conjoined with 'and', they often share a subject.
        E.g., "She went to school and has a friend" - both verbs share "She"
        """
        # Check if this verb is conjoined to another verb
        for token in verb_token.doc:
            # Look for verbs that have this verb as a conjunction
            for child in token.children:
                if child.dep_ == "conj" and child.i == verb_token.i:
                    # This verb is conjoined to 'token'
                    # Try to get the subject from the parent verb
                    for parent_child in token.children:
                        if parent_child.dep_ in ["nsubj", "nsubjpass"]:
                            return self._get_entity_for_token(parent_child, token_to_entity, coref_map)
        
        return None
    
    def _build_coref_map(self, doc, unique_entity_texts):
        """
        Build a simple coreference resolution map.
        Maps pronouns to the most recent PERSON entity mentioned before them.
        """
        coref_map = {}
        last_person = None
        
        for token in doc:
            # Track the most recent person entity
            if token.ent_type_ == "PERSON":
                # Get the full entity text and match to unique entity
                for ent in doc.ents:
                    if token.i >= ent.start and token.i < ent.end:
                        matched = self._match_to_unique_entity(ent.text, unique_entity_texts)
                        last_person = matched
                        break
            # Map pronouns to the last person mentioned
            elif token.pos_ == "PRON" and token.text.lower() in ["he", "she", "him", "her", "his", "hers"]:
                if last_person:
                    coref_map[token.i] = last_person
        
        return coref_map
    
    def _get_entity_for_token(self, token, token_to_entity, coref_map):
        """
        Get the entity text for a token, following compound and proper noun chains.
        Also handles pronouns through coreference resolution.
        """
        # Check if this is a pronoun with a coreference
        if token.i in coref_map:
            return coref_map[token.i]
        
        # Check if token is directly mapped to an entity
        if token.i in token_to_entity:
            return token_to_entity[token.i]
        
        # Check if any child tokens are entities (for compound structures)
        for child in token.children:
            if child.i in coref_map:
                return coref_map[child.i]
            if child.i in token_to_entity:
                return token_to_entity[child.i]
        
        # Check the token's subtree for entities
        for descendant in token.subtree:
            if descendant.i in coref_map:
                return coref_map[descendant.i]
            if descendant.i in token_to_entity:
                return token_to_entity[descendant.i]
        
        return None
